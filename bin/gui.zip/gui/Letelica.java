package gui;

import java.awt.Color;
import java.awt.Graphics;

public class Letelica extends Figura 
{

	public Letelica(Vektor pol, Vektor pom, int h, int a) {
		super(pol, pom);
	}

	@Override
	public Color getBoja() {
		return Color.CYAN;
	}

	@Override
	public void paint(Graphics g) {
		
		g.setColor(Color.CYAN);
		
		double ivica = r/Math.cos(Math.PI/16);
		int x[] = new int[8], y[] = new int[8];	
		
		for(int i = 0; i < 8; i++)
		{
			x[i] = (int)(getCentar().getX() + ivica * Math.cos(i * Math.PI / 4));
			y[i] = (int)(getCentar().getY() + ivica * Math.sin(i * Math.PI / 4));
		}
		
		g.fillPolygon(x, y, 8);
	}

	@Override
	public Vektor getCentar() {
		return null;
	}
	
	
	
}
