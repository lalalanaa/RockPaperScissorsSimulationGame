package gui;

import java.awt.Color;
import java.awt.Graphics;

public class Disk extends Figura {

	public Disk(Vektor pol, Vektor pom) {
		this(pol, pom, 20);
	}
	
	public Disk(Vektor pol, Vektor pom, double r) {
		super(pol, pom, r);
	}

	@Override
	public Color getBoja() {
		return Color.BLUE;
	}

	@Override
	public Vektor getCentar() {
		return polozaj;
	}
	
	@Override
	public void paint(Graphics g) 
	{
		g.setColor(Color.BLUE);
		
		double ivica = r/Math.cos(Math.PI/16);
		int x[] = new int[8], y[] = new int[8];	
		
		for(int i = 0; i < 8; i++)
		{
			x[i] = (int)(getCentar().getX() + ivica * Math.cos(i * Math.PI / 4));
			y[i] = (int)(getCentar().getY() + ivica * Math.sin(i * Math.PI / 4));
		}
		
		g.fillPolygon(x, y, 8);
	}
	

}
