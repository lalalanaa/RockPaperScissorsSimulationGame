package gui;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Simulacija extends Frame {
	
	private Scena scena;
		
	public Simulacija()
	{
		
		setBounds(500, 150, 650, 500);
		setResizable(false);
		
		scena = new Scena(this);
		scena.zapocniPosao();
		add(scena);
		
		setTitle("Simulacija");
		
		setVisible(true);
		
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_SPACE) 
				{ 
					if(scena.getPauzirana())
						scena.nastavi(); 
					else scena.pauziraj();
				}
				
				else if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
				{
					scena.zaustavi();
					dispose();
				}
			}
		});
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				scena.zaustavi();
				dispose();
			}
		});
	}
	
	
	
	public static void main(String[] args) {
		new Simulacija();
		
	}

}
