package gui;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Scena extends Canvas implements Runnable {
	
	private Simulacija owner;
	private int pomeraj;
	private boolean aktivna, pauza;
	private Thread t;
	private String string;
	private ArrayList<Figura> figure;
	
	public Scena(Simulacija s) { this(s, 3); }
	
	public Scena(Simulacija s, int pom)
	{
		setBackground(Color.GRAY);
		owner = s;
		aktivna = true;
		pauza = false;
		figure = new ArrayList<>();
		pomeraj = pom;
		t = new Thread(this);
		string = new String("");
		
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(getPauzirana())
				{
					//requestFocus();
					int x = e.getX();
					int y = e.getY();
					dodajFiguru(new Disk(new Vektor(x,y), Vektor.pseudoslucajan()));
					repaint();
				}
				owner.requestFocus();
			}
		});
	}
	
	
	public void zapocniPosao() { t.start(); pauza = false; }
	
	public boolean getPauzirana() { return pauza; }
	
	
	public void dodajFiguru(Figura f) 
	{
		double x = f.getCentar().getX(), y = f.getCentar().getY(), r = f.getR();
		if(x + r >= getWidth() || x - r < 0 || y + r >= getHeight() || y - r < 0) return;
		
		for(Figura f1 : figure)
			if(f1.kruznicePreklapaju(f)) return;
		
		figure.add(f);
	}
	
	
	public void pomeriFiguru(Figura f)
	{
		double x = f.getCentar().getX(), y = f.getCentar().getY(), r = f.getR();
		if(x + r >= getWidth() || x - r <= 0) { f.getPomeraj().getOrt().set(0, -f.getPomeraj().getOrt().get(0)); }
		else if(y + r >= getHeight() || y - r <= 0) { f.getPomeraj().getOrt().set(1, -f.getPomeraj().getOrt().get(1)); }
		
		for(Figura f1: figure)
		if(f.kruznicePreklapaju(f1)) 
		{
			Vektor pom = f1.getPomeraj();
			f1.setPomeraj(f.getPomeraj());
			f.setPomeraj(pom);
		}
		
		f.getPolozaj().setX(f.getPolozaj().getX() + pomeraj * (double)f.getPomeraj().getOrt().get(0));
		f.getPolozaj().setY(f.getPolozaj().getY() + pomeraj * (double)f.getPomeraj().getOrt().get(1));
	}
	
	
	@Override
	public void paint(Graphics g) {
		g.setFont(new Font("SanSerif", Font.BOLD, 50));
		g.drawString(string, 250, 250);
		for(Figura f : figure)
			f.paint(g);
	}
	
	
	@Override
	public void run() {
		try {
			while(!Thread.interrupted()) 
			{
				if(!pauza) 
				{
					for(Figura f : figure)
						pomeriFiguru(f);
					repaint();
				}
				Thread.sleep(100);
			}
		}catch (InterruptedException e) {}
	}
	
	
	public void zaustavi() { t.interrupt(); }
	
	public void pauziraj() {  string = "PAUZA"; pauza = true; repaint(); }
	
	public void nastavi() { string = ""; pauza = false; repaint(); }
	
}
